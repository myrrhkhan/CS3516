#include <string>
#pragma once
/**
 * @brief Adds tabs at each newline except for very end
 *
 * @param str
 */
std::string add_tabs(std::string str);
